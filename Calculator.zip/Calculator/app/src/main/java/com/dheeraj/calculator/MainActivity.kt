package com.dheeraj.calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.renderscript.ScriptGroup
import android.view.View
import android.widget.Button
import android.widget.TextView
import com.dheeraj.calculator.databinding.ActivityMainBinding
import org.w3c.dom.Text
import java.lang.ArithmeticException
import java.util.zip.Inflater

class MainActivity : AppCompatActivity() {

    private var txtValue: TextView? = null
    var lastNumeric: Boolean = false
    var lastDot: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtValue = findViewById(R.id.txt_result)
    }
    fun onDigit(view: View) {
        txtValue?.append((view as Button).text)
        lastNumeric = true

    }

    fun onOperator(view: View) {
        if (lastNumeric && !isOperatorAdded(txtValue?.text.toString())) {
            txtValue?.append((view as Button).text)
            lastNumeric = false
            lastDot = false
        }
    }
    private fun removeDotAfterZero(result : String): String{
        var value = result
        if(result.contains(".0")){
            value = result.substring(0, result.length-2)
        }
        return value
    }

    private fun isOperatorAdded(value: String): Boolean {
        return if (value.startsWith("-")) {
            false
        } else {
            value.contains("/")
                    || value.contains("-")
                    || value.contains("+")
                    || value.contains("*")
        }
    }

    fun onEqual(view: View) {
        if(lastNumeric){
            var txtResult = txtValue?.text.toString()
            var prefix = ""
            try{
                if(txtResult.startsWith("-")){
                    prefix = "-"
                    txtResult = txtResult.substring(1)
                }

                if(txtResult.contains("-")) {
                    val splitvalue = txtResult.split("-")
                    var one = splitvalue[0]
                    val two = splitvalue[1]

                    if(prefix.isNotEmpty()){
                        one = prefix + one
                    }
                    txtValue?.text = removeDotAfterZero((one.toDouble() - two.toDouble()).toString())
                }

                else if(txtResult.contains("+")){
                    val splitvalue = txtResult.split("+")
                    var one = splitvalue[0]
                    val two = splitvalue[1]

                    if(prefix.isNotEmpty()){
                        one = prefix + one
                    }
                    txtValue?.text = removeDotAfterZero((one.toDouble() + two.toDouble()).toString())
                }
                else if(txtResult.contains("*")){
                    val splitvalue = txtResult.split("*")
                    var one = splitvalue[0]
                    val two = splitvalue[1]

                    if(prefix.isNotEmpty()){
                        one = prefix + one
                    }
                    txtValue?.text = removeDotAfterZero((one.toDouble() * two.toDouble()).toString())
                }

                else if(txtResult.contains("/")){
                    val splitvalue = txtResult.split("/")
                    var one = splitvalue[0]
                    val two = splitvalue[1]

                    if(prefix.isNotEmpty()){
                        one = prefix + one
                    }
                    txtValue?.text = removeDotAfterZero((one.toDouble() / two.toDouble()).toString())
                }


            }catch (e: ArithmeticException){
            }
        }
    }
    fun onDecimalPoint(view: View) {
        if (lastNumeric && !lastDot) {
            txtValue?.append(".")
            lastDot = true
            lastNumeric = false
        }
    }

    fun onClear(view: View) {
        txtValue?.text = ""
        lastDot = false
        lastNumeric = false
    }


}